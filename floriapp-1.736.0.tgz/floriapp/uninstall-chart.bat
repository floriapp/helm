helm uninstall my-floriapp
