helm uninstall my-mongodb
